package com.example.firebasecrud.viewmodel

import android.util.Log
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.firebasecrud.model.ProductModel
import com.google.firebase.Timestamp
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase

class MainViewModel: ViewModel() {

    private var db = Firebase.firestore
    private val products = "products"

    val listProduct: MutableLiveData<List<ProductModel>> by lazy {
        MutableLiveData<List<ProductModel>>()
    }

    fun createProduct(productModel: ProductModel){
        val docRef = db.collection(products)
        docRef.add(productModel.toMap()).addOnSuccessListener {
            Log.d("success", "Berhasil")
        }.addOnFailureListener {
            Log.e("failure", "Gagal")
        }
    }

    fun updateProduct(productModel: ProductModel){
        val docRef = db.collection(products)
        docRef.document(productModel.id!!).update(productModel.toMap()).addOnSuccessListener {
            Log.d("success", "Berhasil")
        }.addOnFailureListener {
            Log.e("failure", "Gagal")
        }
    }

    fun deleteProduct(id: String){
        val docRef = db.collection(products)
        docRef.document(id).delete().addOnSuccessListener {
            Log.d("success", "Berhasil")
        }.addOnFailureListener {
            Log.e("failure", "Gagal")
        }
    }

    fun getListProduct(){
        val docRef = db.collection(products)
        docRef.get().addOnSuccessListener { items ->
            val products = ArrayList<ProductModel>()

            for (item in items.documents){
                val product = ProductModel()
                product.id = item.id
                product.name = item.get("name") as String?
                product.price = item.get("price") as Double?
                product.description = item.data!!["description"] as String?
                product.create_date = item.data!!["create_date"] as Timestamp?
                product.update_date = item.data!!["update_date"] as Timestamp?
                products.add(product)
            }

            listProduct.value = products
        }.addOnFailureListener {
            Log.e("failure", "Gagal")
        }
    }
}